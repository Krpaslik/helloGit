/*
 * Project: IOS - project 2 (synchronization)
 * Author: xpleva09
 * Date: 30.4.2023
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <limits.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/shm.h>
#include <time.h>



int main(int argc,char* argv[]) {
	// Check if the program was called with all needed arguments
	if (argc < 6) {
                fprintf(stderr, "Missing arguments\n");
                return 1;
        }
	// Declare variables to store arguments
	int NZ, NU, TZ, TU, F;
	srand(time(NULL));
	// Check if the argument is integer
	for (int i = 1; i < 6; i++){
		char *endptr;
        	int val = strtol(argv[i], &endptr, 10);
        	if (*endptr != '\0' || endptr == argv[i]) {
        		fprintf(stderr, "Invalid argument\n");
			return 1;
        	} else {
			// Assign the value to the corresponding variable
			switch (i) {
			case 1: NZ = val;
				break;
			case 2: NU = val;
                                break;
			case 3: TZ = val;
                                break;
			case 4: TU = val;
                                break;
			case 5: F = val;
                                break;
			default: break;
			}
		}
	}
	// Check if the arguments are within allowed range
	if (NZ < 0 || NU < 0 || TZ < 0 || TZ > 10000 || TU < 0 || TU > 100 || F < 0 || F > 10000) {
		fprintf(stderr, "Argument out of range\n");
		return 1;
	}
	
	FILE *file;
	if ((file = fopen("proj2.out","w")) == NULL){
        	fprintf(stderr, "Can't open file\n");
        	return 1;
	}
	setbuf(file, NULL);
	
	// Initialization of variable A for counting order of the processes
	uint32_t *A = mmap(NULL,sizeof(uint32_t),PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_SHARED, -1, 0);
	*A = 0;
	
	// Initialization of variable open for checking if postoffice is closed
	bool *open =  mmap(NULL,sizeof(bool),PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_SHARED, -1, 0);
        *open = true;
	
	// Initialization of semaphores
	sem_t *queque = mmap(NULL, sizeof(sem_t) * 3, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_SHARED, -1, 0);
	sem_init(&queque[0], 1, 0);
        sem_init(&queque[1], 1, 0);
        sem_init(&queque[2], 1, 0);
	
	sem_t *officer = mmap(NULL, sizeof(sem_t), PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_SHARED, -1, 0);
        sem_init(officer, 1, 0);

	// Creating NZ number of customer processes
	for (int i = 0; i < NZ; i++) {
		int seed = rand(); // Creating random seed for every separate process
		int id = fork();
		if (id == 0) {
			srand(seed);
			int idZ = i + 1;
			fprintf(file, "%i: Z %i: started\n",*A += 1,idZ);	
			usleep(rand() % (TZ + 1));
			if (*open) {
				int service = rand() % 3;
				sem_post(&queque[service]);
				fprintf(file, "%i: Z %i: entering office for a service %i\n",*A += 1,idZ, service + 1);
				sem_wait(officer);
				fprintf(file, "%i: Z %i: called by office worker\n",*A += 1,idZ);
				usleep(rand() % 11);
			}
			fprintf(file, "%i: Z %i: going home\n",*A += 1,idZ);
			exit(0);			
		}
	}
	
	// Creating NU number of officer processes
	for (int i = 0; i < NU; i++) {
		int seed = rand(); // Creating random seed for every separate process
                int id = fork();
                if (id == 0) {
			srand(seed);
                        int idU = i + 1;
                        fprintf(file, "%i: U %i: started\n",*A += 1,idU);
			sem_post(officer);
			while(true){
				int result = -1;
				for (int j = 0; j < 3; j++) {
					if (sem_trywait(&queque[j]) == 0) {
						result = j;
						break;
					}
				}
				if (result >= 0 || *open) {
					if (result >= 0) {
						fprintf(file, "%i: U %i: serving a service of type %i\n",*A += 1,idU, result + 1);
						usleep(rand() % 11);
						fprintf(file, "%i: U %i: service finished\n",*A += 1,idU);
						sem_post(officer);
					}
					else {
						sem_wait(officer);
						fprintf(file, "%i: U %i: taking break\n",*A += 1,idU);
						usleep(rand() % (TU + 1));
						fprintf(file, "%i: U %i: break finished\n",*A += 1,idU);
						sem_post(officer);
					}

				} 
				else {
					fprintf(file, "%i: U %i: going home\n",*A += 1,idU);
					exit(0);
				}
			}
                }
        }
	
	usleep(rand() % (F / 2 + 1) + (F / 2));
	*open = false;
	fprintf(file, "%i: closing\n",*A += 1);
	
	while(wait(NULL)>0);
	
	fclose(file);
	munmap(A,sizeof(uint32_t));
	munmap(open, sizeof(bool));
	munmap(officer, sizeof(sem_t));
	munmap(queque, sizeof(sem_t) * 3);
	return 0;
}

